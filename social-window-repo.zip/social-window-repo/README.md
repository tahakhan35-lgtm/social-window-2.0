# Social Window

A single-file social app prototype (guest accounts, posts, stories, video, explore, messages)
stored locally in the browser via IndexedDB.

## How to publish this on GitHub Pages

1. Create a new repository (or open your existing one).
2. Upload **index.html** so it sits at the repository root — same level as this README.md,
   not inside any subfolder.
3. Go to **Settings → Pages**.
4. Under "Build and deployment", set:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/ (root)**
5. Click **Save**, then wait 1-2 minutes for the green "Your site is live at..." banner.
6. Open the link shown there — the app will load directly.

If you ever see a 404 "File not found" page, it almost always means index.html
ended up inside a subfolder, or the Pages folder setting isn't "/ (root)".
